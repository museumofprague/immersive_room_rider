/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package peasy.org.apache.commons.math.geometry;

/**
 * This class is a utility representing a rotation order specification for
 * Cardan or Euler angles specification.
 * 
 * This class cannot be instanciated by the user. He can only use one of the
 * twelve predefined supported orders as an argument to either the
 * {@link Rotation#Rotation(RotationOrder,double,double,double)} constructor or
 * the {@link Rotation#getAngles} method.
 * 
 * @version $Revision: 620312 $ $Date: 2008-02-10 12:28:59 -0700 (Sun, 10 Feb
 *          2008) $
 * @since 1.2
 */
public final class RotationOrder {

	/**
	 * Private constructor. This is a utility class that cannot be instantiated
	 * by the user, so its only constructor is private.
	 * 
	 * @param name
	 *            name of the rotation order
	 * @param a1
	 *            axis of the first rotation
	 * @param a2
	 *            axis of the second rotation
	 * @param a3
	 *            axis of the third rotation
	 */
	private RotationOrder(final String name, final Vector3D a1, final Vector3D a2,
			final Vector3D a3) {
		this.name = name;
		this.a1 = a1;
		this.a2 = a2;
		this.a3 = a3;
	}

	/**
	 * Get a string representation of the instance.
	 * 
	 * @return a string representation of the instance (in fact, its name)
	 */
	public String toString() {
		return name;
	}

	/**
	 * Get the axis of the first rotation.
	 * 
	 * @return axis of the first rotation
	 */
	public Vector3D getA1() {
		return a1;
	}

	/**
	 * Get the axis of the second rotation.
	 * 
	 * @return axis of the second rotation
	 */
	public Vector3D getA2() {
		return a2;
	}

	/**
	 * Get the axis of the second rotation.
	 * 
	 * @return axis of the second rotation
	 */
	public Vector3D getA3() {
		return a3;
	}

	/**
	 * Set of Cardan angles. this ordered set of rotations is around X, then
	 * around Y, then around Z
	 */
	public static final RotationOrder XYZ = new RotationOrder("XYZ", Vector3D.plusI,
			Vector3D.plusJ, Vector3D.plusK);

	/**
	 * Set of Cardan angles. this ordered set of rotations is around X, then
	 * around Z, then around Y
	 */
	public static final RotationOrder XZY = new RotationOrder("XZY", Vector3D.plusI,
			Vector3D.plusK, Vector3D.plusJ);

	/**
	 * Set of Cardan angles. this ordered set of rotations is around Y, then
	 * around X, then around Z
	 */
	public static final RotationOrder YXZ = new RotationOrder("YXZ", Vector3D.plusJ,
			Vector3D.plusI, Vector3D.plusK);

	/**
	 * Set of Cardan angles. this ordered set of rotations is around Y, then
	 * around Z, then around X
	 */
	public static final RotationOrder YZX = new RotationOrder("YZX", Vector3D.plusJ,
			Vector3D.plusK, Vector3D.plusI);

	/**
	 * Set of Cardan angles. this ordered set of rotations is around Z, then
	 * around X, then around Y
	 */
	public static final RotationOrder ZXY = new RotationOrder("ZXY", Vector3D.plusK,
			Vector3D.plusI, Vector3D.plusJ);

	/**
	 * Set of Cardan angles. this ordered set of rotations is around Z, then
	 * around Y, then around X
	 */
	public static final RotationOrder ZYX = new RotationOrder("ZYX", Vector3D.plusK,
			Vector3D.plusJ, Vector3D.plusI);

	/**
	 * Set of Euler angles. this ordered set of rotations is around X, then
	 * around Y, then around X
	 */
	public static final RotationOrder XYX = new RotationOrder("XYX", Vector3D.plusI,
			Vector3D.plusJ, Vector3D.plusI);

	/**
	 * Set of Euler angles. this ordered set of rotations is around X, then
	 * around Z, then around X
	 */
	public static final RotationOrder XZX = new RotationOrder("XZX", Vector3D.plusI,
			Vector3D.plusK, Vector3D.plusI);

	/**
	 * Set of Euler angles. this ordered set of rotations is around Y, then
	 * around X, then around Y
	 */
	public static final RotationOrder YXY = new RotationOrder("YXY", Vector3D.plusJ,
			Vector3D.plusI, Vector3D.plusJ);

	/**
	 * Set of Euler angles. this ordered set of rotations is around Y, then
	 * around Z, then around Y
	 */
	public static final RotationOrder YZY = new RotationOrder("YZY", Vector3D.plusJ,
			Vector3D.plusK, Vector3D.plusJ);

	/**
	 * Set of Euler angles. this ordered set of rotations is around Z, then
	 * around X, then around Z
	 */
	public static final RotationOrder ZXZ = new RotationOrder("ZXZ", Vector3D.plusK,
			Vector3D.plusI, Vector3D.plusK);

	/**
	 * Set of Euler angles. this ordered set of rotations is around Z, then
	 * around Y, then around Z
	 */
	public static final RotationOrder ZYZ = new RotationOrder("ZYZ", Vector3D.plusK,
			Vector3D.plusJ, Vector3D.plusK);

	/** Name of the rotations order. */
	private final String name;

	/** Axis of the first rotation. */
	private final Vector3D a1;

	/** Axis of the second rotation. */
	private final Vector3D a2;

	/** Axis of the third rotation. */
	private final Vector3D a3;

}
